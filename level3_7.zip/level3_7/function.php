<?php

function pages($array)
{
  return ceil(count($array) / 5);
}

function getFromGet ($name, $default = 1)
{
  return array_key_exists($name, $_GET) ? $_GET[$name] : $default;
}

function numberPages ($array, $name)
{
    for ($i=1; $i<= pages($array); $i++)
  {
    if (getFromGet($name, 1) == $i)
    {
      echo $i;
    }
    else
    {
      ?> <a href="<?php echo sprintf("index.php?page=%s", $i) ?>"><?php echo $i ?></a>
      <?php
    }
  }
}

function getFromPost ($name, $default = FALSE)
{
  return array_key_exists($name, $_POST) ? $_POST[$name] : $default;
}

function loadSentenses ($fileName)
{
  $text       = file_get_contents($fileName);
  $sentenses = explode('.', $text);
  foreach ($sentenses as $key => $value)
  {
    if (!$value) unset ($sentenses[$key]);
  }
  return $sentenses;
}
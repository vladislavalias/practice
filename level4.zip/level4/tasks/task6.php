<?php

// задание 6
// создать калькулятор процентных начислений от вклада на выбранное количество лет
// с заданной процентной ставкой от депозита и стартовой суммой.
// [ так же реализовать расчет реальной суммы с учетом инфляции ]

$numberDeposit = getFromPost('deposit') * exp(getFromPost('period')*log(1 + getFromPost('persent') / 100));

?>
<form action="index.php" method="post">
Ставка депозита: <input type="text" name="deposit" value="<?php echo getFromPost('deposit') ?>"><br />
Годовая ставка %: <input type="text" name="persent" value="<?php echo getFromPost('persent') ?>"> <br />
Период: <input type="text" name="period" value="<?php echo getFromPost('period') ?>"> <br />
<input type="submit" value="Посчитать"><br />
Сумма с учетом начисленных процентов: <?php echo $numberDeposit, '<br>' ?>
</form>
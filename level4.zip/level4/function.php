<?php


/**
 * Извлечение переменной из ПОСТа.
 * 
 * @param string $name Название элемента.
 * @param mixed $default Значение по умолчанию.
 * @return mixed
 */
function getFromPost($name, $default = FALSE)
{
  return getFrom($_POST, $name, $default);
}

/**
 * Проверка на наличие файла, соответствующего переменной.
 * 
 * @param type $array Перечень доступных значений.
 * @param type $name Значение элемента.
 * @param type $default Значение по умолчанию.
 * @return type
 */
function getFrom($array, $name, $default = FALSE)
{
  if (!$array || !$name) return $default;
  
  return array_key_exists($name, $array) ? $array[$name] : $default;
}

/**
 * ����� ���������
 * 
 * @param type $name 
 * @param type $default
 * @return type
 */
function optIsSelected($name, $default = '')
{
    return getFromPost($name) == $name ? 'selected="selected"' : $default;
}

function getFromSession($name)
{  
  return array_key_exists($name, $_SESSION) ? $_SESSION[$name] : '';
}
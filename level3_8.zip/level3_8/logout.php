<?php

session_start();
$_SESSION['login'] = 0;
header("Location: http://practic/level3_8/index.php");
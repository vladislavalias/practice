$(document).ready(function(){
    $('.ava_pic').on('mouseover', function(event){
      $('.choose_pic').slideDown('fast');
    });

    $('.ava_pic').on('mouseout', function(event){
      $('.choose_pic').slideUp('fast');
    });
    
    $('#country_select').on('change', function(){
      var citySelectName = 'city_' + $(this).val();
      
      $('select[id^=city_]').css('display', 'none');
//      $('#city').css('display', 'table-row');
      $('#city').fadeIn('fast');
      $('#city').find('div.hidden').fadeIn('fast');
      $('#' + citySelectName).css('display', 'inline-block');
    });
    
    $('.show_adress_select').on('change', function(){
      $('#street').fadeIn();
      $('#street').find('div.hidden').fadeIn();
      $('#house').fadeIn();
      $('#house').find('div.hidden').fadeIn();
    });
    
    $('#registration-form').submit(function(){
      var result = false;
      $('.error').css('display', 'none');
      
      result = !result && validateOnEmpty('#registration-name', 'INPUT NAME, BEACH!');
      result = !result && validateOnEmpty('#registration-password', 'INPUT PASSWORD, BEACH!');
      result = !result && validateOnEmpty('#registration-password2', 'REPEAT PASSWORD, BEACH!');
      result = !result && validateOnEmpty('#registration-email', 'input data, please!');
      result = !result && validateOnEmpty('#country_select', 'input data, please!');
      
      return result;
    });
    
    $('.close_error').on('click', function(){
      $(this).parents('.error').css('display', 'none');
    });
  }
);
  
function validateOnEmpty(elementName, errorMessage)
{
  return ("" == $(elementName).val() ? showError(elementName, errorMessage) : true); 
}

function showError(elementName, message)
{  
  var errorContainer = $(elementName).nextAll('.error');
  errorContainer.css('display', 'block');
  errorContainer.children('.error-message').html(message);
  
  return false;
}
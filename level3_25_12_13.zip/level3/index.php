<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once 'functions.php';

// задание 1 ****
// написать калькулятор
// вводные данные - любые числа, соответственно должны обрабатываться ошибки со строками
// операция должна задаваться радиобаттонами, реализуемые операции
// умножить, сложить, вычесть, разделить, корень, квадрат, и возведение в степень Н
// дополнение: после, реализовать выполнение любой последовательности вычислений,
// но при этом, фильтровать от неверного ввода

?>
<form action="index.php" method="post">
  <?php
    $formInputs = array(
        array('type' => 'text',   'name' => 'number', 'text' => 'Введите число'),
        array('type' => 'radio',  'name' => 'operation', 'text' => '+', 'value' => '+'),
        array('type' => 'radio',  'name' => 'operation', 'text' => '-', 'value' => '-'),
        array('type' => 'radio',  'name' => 'operation', 'text' => '*', 'value' => '*'),
        array('type' => 'radio',  'name' => 'operation', 'text' => '/', 'value' => '/'),
        array('type' => 'radio',  'name' => 'operation', 'text' => '^2', 'value' => '2'),
        array('type' => 'text',   'name' => 'number2'),
        array('type' => 'submit', 'name' => 'submit', 'value' => 'Посчитать'),
    );
  ?>
  
  <?php echo print_inputs($formInputs) ?>
    Результат: 
    <?php 
    if ($_POST['operation'] == '+')
    {
    $resultOper = $_POST['number'] + $_POST['number2'];
    }
    elseif ($_POST['operation'] == '-') 
{
     $resultOper = $_POST['number'] - $_POST['number2'];
}

    elseif ($_POST['operation'] == '*') 
{
     $resultOper = $_POST['number'] * $_POST['number2'];
}

    elseif ($_POST['operation'] == '/') 
{
     $resultOper = $_POST['number'] / $_POST['number2'];
}
    echo $resultOper;
?>
</form>
<?php

// задание 2 *****
// есть входная строка "asdddfghhhjklll"
// требуется убрать из нее все повторения символов
// так же должна быть корректная обработка пробелов на удаление повторений
// дополнение - реализовать два метода.

$string = "asdddfghhhjkllladfghaaaaa";
//         asdfghjkladfgh
$result = $string[0];

echo $string . '<br />';

for ($i = 1; $i <= strlen($string) - 1; $i++)
{
  if ($string[$i] != $string[$i - 1])
  {
    $result = $result . $string[$i];
  }
}
echo $result;
echo '<br>';

$result = '';
for ($i = 0; $i <= strlen($string) - 1; $i++)
{
  if ($i == strpos($string, $string[$i]))
  {
    $result .= $string[$i];
  }
}

echo $result . '<br />';

//for ($i = 0; $i <= strlen($result) - 1; $i++)
//{
//
//    $pos = strpos($string, $string[$i], 0);
//    $max = strlen($result) - 1;
//
//    if (substr_count($result, $result[$i]) == 1)
//    {
//     echo $result[$i];   
//    }
//    else
//    {
//        if ($pos < $max)
//        {
//            $max = $pos; 
//            echo $result[$i];
//        }
//        else
//        {
//            continue;
//        }
//    }
//}
echo '<br>';

// задание 3 **
// реализовать вычисление длины окружности по задаваемом в форме радиусу

?>

<form action="index.php" method="post">
Радиус окружности: <input type="text" size="18" name="radius" value="<?php echo $_POST['radius'] ?>">
<input type="submit"> <br />
Длина окружности: 
<?php
  $result = 2 * M_PI * $_POST['radius'];
  echo sprintf('%.2f', $result);
?>   
</form>

<?php

// задание 4 *
// есть список песен {1, 2, 3, 4, 5}
// реализовать произвольный выбор одной из них

$playlist = array('wind of change', 'sonne', 'new people', 'johnny be good', 'show must go on');
$n = rand(0, count($playlist) - 1);
echo $playlist[$n];
echo '<br>';

// задание 5 *
// есть массив чисел {5, 6, 9, 2, 4, 0}
// реализовать сортировку массива по возрастанию и по убыванию
// результат и исходный массив выводить на экран
// в качестве бонуса можно сделать переключатель - выбор направления сортировки

$array = array(5, 6, 9, 2, 4, 0);
while (list($key, $val) = each($array)) 
{
    echo "$val", ' ';
}
echo '<br>';
?>
<form action="index.php" method="post">
    <input type="radio" name="way" value="+">+<br>
    <input type="radio" name="way" value="">-<br>
    <input type="submit">
</form>

<?php


echo '<br>';

if ($_POST['way'] == '+')
{
    sort($array);
    reset($array);
    while (list($key, $val) = each($array)) 
    {
        echo "$val", ' ';
    }  
}
else
{
    rsort($array);
    reset($array);
    while (list($key, $val) = each($array)) 
    {
        echo "$val", ' ';
    }
}
// задание 6 ****
// реализовать форматер текущей даты
// должна быть форма с выбором требуемого формата вывода даты
// и соответственно вывод ее в выбранном формате
// минимум 7 форматов, в виде год/месяц/день часы:минуты:секунды
// к этому можно добавить дни недели, названия месяцев и ведущие нули в цифрах
// 13/12/02
// 2013-12-2
// 02 December 2013
// 02 Dec 2013
// 02 Mon Dec 2013

$time = '11/16/2001 20:15:58';
$time2 = preg_replace('/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})/ui', '$3-$2-$1',$time);
echo $time2, '<br>';
echo date('y-F-d H:i:s');
